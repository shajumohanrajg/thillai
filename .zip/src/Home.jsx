
import Hero from "./components/hero";


import Footer from "./components/footer/Footer";

function App() {
  return (
    <>
      <Hero />
      <div style={{padding:'50px',textAlign:'center'}}>
     Need Content For this
     </div>
      <Footer />
      
    </>
  );
}

export default App;
