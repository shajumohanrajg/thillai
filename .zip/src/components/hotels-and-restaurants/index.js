export { default } from "./HotelsAndRestaurants";
