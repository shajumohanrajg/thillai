import React from 'react';
import { Routes, Route, Link } from 'react-router-dom';
import Home from './Home';
import Search from './search';
import Register from './register3';
import {
  createTheme,
  responsiveFontSizes,
  ThemeProvider,
} from "@mui/material/styles";

// import Contact from './Contact';
let theme = createTheme({
  palette: {
    primary: {
      main: "#2196f3",
    },
    secondary: {
      main: "#f50057",
    },
  },
  typography: {
    fontFamily: "Poppins, sans-serif",
  },
  textfield:{
    color:'red'
  }
});

// Make the theme responsive
theme = responsiveFontSizes(theme);
function App() {
  return (
    <div>
    
    <ThemeProvider theme={theme}>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/register3" element={<Register />} />
        <Route path="/search" element={<Search />} />
        {/* <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} /> */}
      </Routes>
      </ThemeProvider>
    </div>
  );
}

export default App;
